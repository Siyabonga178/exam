/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2examgui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;


/**
 *
 * @author Student
 */   
     public class Product  extends JFrame  {

    // Declare components
    private JTextField txtCustomerName;
    private JComboBox<String>cmbProducts;
    private JTextField txtPrice;
    private JButton btnProcess;
    
    //Menu Components
    private JMenuBar menuBar;
    private JMenu menuFile,menuTools;
    private JMenuItem menuItemExit,menuItemProcess,menuItemClear;
    
         
    // Constructor
    public Product App() {

        setTitle("Product App");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        //Initialize Menu Bar
        menuBar = new  JMenuBar();
        menuFile = new JMenu("File");
        menuTools = new JMenu("Tools");
        
        menuItemExit = new JMenuItem("Exit");
        menuItemProcess = new JMenuItem("Process");
        menuItemClear = new JMenu("Clear");
        
        menuFile.add(menuItemExit);
        
        menuTools.add(menuItemClear);
        menuBar.add(menuFile);
        menuBar.add(menuTools);
        setJMenuBar(menuBar);
        
        //Components
          JLabel lblCustomer = new JLabel("Customer Name:");
          lblCustomer.setBounds(30, 40, 120, 25);
        add(lblCustomer);
        txtCustomerName = new JTextField();
        

       txtCustomerName.setBounds(150, 40, 200, 25);
       add(txtCustomerName);
       
       JLabel lblProduct=new JLabel("Select Product:");
       lblProduct.setBounds(35, 95, 130,40);
       add(lblProduct);
      
     String[]Products = {":Cozy Nights Monarch", "Restonic Barbados","Sealy phuket"};
     cmbProducts = new JComboBox<>(Products);
     cmbProducts.setBounds(150,80,210,35);
     add(cmbProducts);
     
     JLabel lblPrice = new JLabel("Enter Price:");
     lblPrice.setBounds(30, 145, 126, 28);
     add(lblPrice);
     
     txtPrice = new JTextField();
     txtPrice.setBounds(150,140,200,25);
     add(txtPrice);
     
     
     btnProcess = new JButton("PROCESS");
     btnProcess.setBounds(160, 190, 210, 240);
     add(btnProcess);
     
     //Action Listeners
     
     btnProcess.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
    });
      menuItemProcess.addActionListener(new ActionListener(){
       @Override
       public void actionPerformed(ActionEvent e){
           clearFields();
           
       }

            private void clearFields() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
      });
      menuItemExit.addActionListener(new ActionListener(){
          @Override
          public void actionPerformed(ActionEvent e){
              System.exit(0);
              
          }
      });
    
    private void processApplication() throws IOException{
        try{
            String customerName = txtCustomerName.getText().trim();
            String productName = (String)
                    cmbProducts.getSelectedItem();
                 double price = Double.parseDouble(txtPrice.getText().trim());
                 
                 ProductCalculations calc = new ProductCalculations(price);
                 double commission = calc.GetCommission();
                   double vat =  calc.GetVat();
                   double total = calc.GetTotal();
        
                   //Display message
                   String message = String.format(customerName, productName, commissionTotal);
                   JOptionPane.showMessageDialog(this,"message", JOptionPane.INFORMATION_MESSAGE);
                   
                   //Save to data.txt
                   try(PrintWriter writer = new PrintWriter(new FileWriter("data.txt",true))){
                       writer.println("DATA LOG");
                       
                       System.out.println("");
                       
                       writer.println("Customer Name:" + customerName);
                       writer.println("Product: + productName");
                       writer.println("VAT:R" + vat);
                       
                       writer.println("COMMISSION:R" + commission);
                       writer.println("TOTAL:R" + total);
                       writer.println("**************************");
                   }catch
                     (NumberFormatException ex){
                       JOptionPane.showMessageDialog(this, "Please Enter a valid numeric price.","ERROR",JOptionPane.ERROR_MESSAGE);
                   }catch
                       (IOException ex){
                       JOptionPane.showMessageDialog(this,"ERROR saving to file","ERROR",JOptionPane.ERROR_MESSAGE );
                   }
                   }
         private void clearFields(){
             
         txtCustomerName.setText("");
         txtPrice.setText("");
         cmbProducts.setSelectedIndex(0);
         }
        public static void main(String[]args) {
            SwingUtilities.invokeLater())->{
            new ProductApp().setVisisble(true);
        
        }      
                   
                   
                        
            ));
   
        
    
    
        

        

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question1javaapp;

/**
 *
 * @author Student
 */
public class Product implements IProducts {

    public static void main(String[] args) {
        //1D Array
        
        private String[] productNames;
        //2D Array
        private int[][] salesData;
        
        public Product(String[ productNames[]], int[][] salesData){
            this.productNames = productNames;
            this.salesData = salesData;
        }
        @Override
        public int  GetTotalProductSold(){
           int total = 0;
           for(int i =0; i< salesData.length;i++){
               for(int j= 0; j < salesData[i].length;j++){
                   total+= salesData[i][j];
               }
           }
           return total;
        }
    @Override 
    public double GetAverageProductSold(){
        int total = GetTotalProductSold();
        int count = 0;
        for(int i=0; i < salesData.length; i++){
            count+=salesData.length;
            
        }
        return count ==0? 0.0:(double) total/count;
    }
    @Override
    public String GetMostPopularProduct(){
        int maxSales =-1;
        int bestProductionIndex = 0;
        
        for(int i =0; i< salesData.length;i++){
            int productTotal = o;
            for(int j =0;j< salesData[i].length;j++){
                productTotal +=salesData[i][j];
              
                
            }
            if(productTotal > maxSales){
                maxSales = productTotal;
                bestProductionIndex = i;
            }
        }
        return 
                productNames[bestProductIndex]+"("" maxSales"+);
    }
        
    }
}

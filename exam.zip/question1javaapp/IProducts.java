/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.question1javaapp;

/**
 *
 * @author Student
 */
interface IProducts {
     int GetTotalProductSold();
    double GetAverageProductSold();
    String GetMostPopularProduct();
}

